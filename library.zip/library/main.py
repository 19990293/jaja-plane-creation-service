import csv

books = {"Narnia" : 1, "Sherlock Holmes" : 2, "Red Rising" : 3, "Exquisite Cooking" : 4, "Diddy: An Excursion" : 5}
userBookId = int(input("Please input the ID of the book you would like "))
name = input("Please enter your full name ")
memberId = int(input("Please enter your member id "))
email = input("Please enter your email ")
try:
    bookId = int(userBookId)
except:
    print("No way jose")
    exit()
if bookId not in books.values():
    print("Yikes")
    exit()
row = [name, memberId, bookId, email]
# header = ["Name", "Member ID", "Book ID","Email" ]

with open("data.csv", mode="a", newline="") as file:
    writer = csv.writer(file)
    # writer.writerow(header)
    writer.writerow(row)


with open("data.csv", mode ="r") as file:
    reader = csv.DictReader(file)
    for row in reader:
        if int(row["Book ID"]) == bookId:
            print("record found:", row)
            break
        else:
            print("ID does not exist")




