import ctypes
import os 
dir_path = os.path.dirname(os.path.realpath(__file__))

ctypes.windll.user32.SystemParametersInfoW(20, 0, r"C:\Users\connor.crossley\Downloads\hamming\ham.jpg", 3)
print(f'HAM: {dir_path}')