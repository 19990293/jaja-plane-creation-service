user_input = input("Please type a sentence: ")
split_input = user_input.split() 
input_length = sorted(split_input, key=len)
longest_even_word = ""

for word in input_length:
    if len(word) % 2 ==0:
                if len(word) > len(longest_even_word):
                     longest_even_word = word 

if longest_even_word: 
    print(longest_even_word, "is the longest even word in the sentence.")
else:
    print("There are no even words in the sentence.")