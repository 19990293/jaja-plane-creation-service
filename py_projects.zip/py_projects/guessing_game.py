import random

number = random.randint(1,100)
guess = 0

while guess != number:

    guess = int(input("Enter Guess: "))

    if (guess < number):
        print("The number is higher!")
    elif (guess > number):
        print("The number is lower!")
    else:
        print("You guessed right!") 