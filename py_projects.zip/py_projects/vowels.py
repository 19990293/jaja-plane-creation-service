text = input("Type away: ")


count = 0

for character in text: 
    if (character in "aAeEiIoOuU"):
        count += 1

print("Vowels", count)