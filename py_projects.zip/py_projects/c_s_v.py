import csv
import json
import pandas
data = []
choice = input("Please select an option, 1 Write to CSV File, 2 View the CSV File, 3 Convert the CSV File to JSON, 4 View JSON, 5 Exit, 6 all of the above ")
if choice == "1":
    fname = input('Enter your first name \n')
    lname = input('Enter your last name \n')
    email = input('Enter your email \n')
    fname2 = input('Enter your first name \n')
    lname2 = input('Enter your last name \n')
    email2 = input('Enter your email \n')
    fname3 = input('Enter your first name \n')
    lname3 = input('Enter your last name \n')
    email3 = input('Enter your email \n')
    with open("names.csv", mode="w") as csvfile:
        fieldnames = ["first_name", "last_name", "email"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"first_name": fname, "last_name": lname, "email": email})
        writer.writerow({"first_name": fname2, "last_name": lname2, "email": email2})
        writer.writerow({"first_name": fname3, "last_name": lname3, "email": email3})

elif choice == "2":
    df = pandas.read_csv("names.csv")
    print(df.tail(3))



elif choice == "3":
    csv_file = open("names.csv", "r")
    csv_reader = csv.reader(csv_file)
    field_names = next(csv_reader)
    for row in csv_reader:
        data.append(dict(zip(field_names, row)))
    json_data = json.dumps(data)
    json_file = open("data.json", 'w')
    json_file.write(json_data)
    csv_file.close()
    json_file.close()
    print("Your csv file has been successfully converted.")

elif choice == "4":
  with open('data.json') as json_info:
    json_file = json.load(json_info)
    print(json_file)

elif choice == "5":
    print("The app has been closed, have a good day")

elif choice == "6":
    fname = input('Enter your first name \n')
    lname = input('Enter your last name \n')
    email = input('Enter your email \n')
    fname2 = input('Enter your first name \n')
    lname2 = input('Enter your last name \n')
    email2 = input('Enter your email \n')
    fname3 = input('Enter your first name \n')
    lname3 = input('Enter your last name \n')
    email3 = input('Enter your email \n')
    with open("names.csv", mode="w") as csvfile:
        fieldnames = ["first_name", "last_name", "email"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"first_name": fname, "last_name": lname, "email": email})
        writer.writerow({"first_name": fname2, "last_name": lname2, "email": email2})
        writer.writerow({"first_name": fname3, "last_name": lname3, "email": email3})
    df = pandas.read_csv("names.csv")
    print(df.tail(3))
    csv_file = open("names.csv", "r")
    csv_reader = csv.reader(csv_file)
    field_names = next(csv_reader)
    print(field_names)
    for row in csv_reader:
        data.append(dict(zip(field_names, row)))
    json_data = json.dumps(data)
    json_file = open("data.json", 'w')
    json_file.write(json_data)
    print(data)
    csv_file.close()
    json_file.close()

else:
    print("Please enter a valid number")