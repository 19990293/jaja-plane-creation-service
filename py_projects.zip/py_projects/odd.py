number = int(input("Enter a number: "))

if(number % 2) == 0:
    print("{0} is even number".format(number))

else:
    print("{0} is odd number".format(number))