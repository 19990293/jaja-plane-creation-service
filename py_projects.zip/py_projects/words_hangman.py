word_list = [
    'Bannana',
    'Strawberry',
    'Blueberry',
    'Kiwi',
    'Pomegranate',
    'Glowberry',
    'Watermelon',
    'Java',
    'Steak',
    'Milk',
    'Coffee']