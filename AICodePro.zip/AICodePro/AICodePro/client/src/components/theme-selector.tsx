import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Check, Palette } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Theme {
  name: string;
  primary: string;
  background: string;
  foreground: string;
  variant: 'professional' | 'tint' | 'vibrant';
}

const themes: Theme[] = [
  {
    name: "Default",
    primary: "222.2 47.4% 11.2%",
    background: "0 0% 100%",
    foreground: "222.2 47.4% 11.2%",
    variant: "professional",
  },
  {
    name: "Ocean",
    primary: "201 96% 32%",
    background: "201 96% 98%",
    foreground: "201 96% 12%",
    variant: "vibrant",
  },
  {
    name: "Forest",
    primary: "150 96% 29%",
    background: "150 96% 98%",
    foreground: "150 96% 12%",
    variant: "tint",
  },
  {
    name: "Sunset",
    primary: "20 96% 40%",
    background: "20 96% 98%",
    foreground: "20 96% 12%",
    variant: "vibrant",
  },
  {
    name: "Royal",
    primary: "272 96% 32%",
    background: "272 96% 98%",
    foreground: "272 96% 12%",
    variant: "professional",
  },
];

export function ThemeSelector() {
  const [currentTheme, setCurrentTheme] = useState(themes[0]);

  const updateTheme = (theme: Theme) => {
    setCurrentTheme(theme);
    document.documentElement.style.setProperty("--theme-primary", theme.primary);
    document.documentElement.style.setProperty("--theme-background", theme.background);
    document.documentElement.style.setProperty("--theme-foreground", theme.foreground);
    localStorage.setItem("selected-theme", JSON.stringify(theme));
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem("selected-theme");
    if (savedTheme) {
      const theme = JSON.parse(savedTheme);
      updateTheme(theme);
    }
  }, []);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="fixed top-4 right-4 z-50">
          <Palette className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {themes.map((theme) => (
          <DropdownMenuItem
            key={theme.name}
            onClick={() => updateTheme(theme)}
            className="flex items-center justify-between"
          >
            <span>{theme.name}</span>
            {currentTheme.name === theme.name && (
              <Check className="h-4 w-4 text-primary" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}