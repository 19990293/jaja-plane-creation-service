import { useState, useEffect, Children, ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Navigation } from "./navigation";
import { Progress } from "./progress";

interface SlideDeckProps {
  children: ReactNode;
}

export function SlideDeck({ children }: SlideDeckProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const slideCount = Children.count(children);

  const navigate = (direction: number) => {
    const newIndex = currentIndex + direction;
    if (newIndex >= 0 && newIndex < slideCount) {
      setCurrentIndex(newIndex);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "Space") {
        navigate(1);
      } else if (e.key === "ArrowLeft") {
        navigate(-1);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentIndex]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-background to-background/80">
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ 
            duration: 0.1
          }}
          className="w-full h-full"
        >
          {Children.toArray(children)[currentIndex]}
        </motion.div>
      </AnimatePresence>

      <Navigation
        onPrevious={() => navigate(-1)}
        onNext={() => navigate(1)}
        canGoPrevious={currentIndex > 0}
        canGoNext={currentIndex < slideCount - 1}
      />

      <Progress current={currentIndex + 1} total={slideCount} />
    </div>
  );
}