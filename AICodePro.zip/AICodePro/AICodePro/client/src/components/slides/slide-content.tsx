import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";

interface SlideContentProps {
  title: string;
  subtitle?: string;
  content: string;
  image: string;
  index: number;
  total: number;
}

export function SlideContent({ title, subtitle, content, image, index, total }: SlideContentProps) {
  return (
    <div className="w-full h-full flex items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.1 }}
        className="w-full max-w-6xl"
      >
        <Card className="bg-card/95 backdrop-blur shadow-xl border-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.1 }}
            >
              <div>
                <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                  {title}
                </h1>
                {subtitle && (
                  <p className="text-xl text-muted-foreground mt-2">{subtitle}</p>
                )}
              </div>
              <p className="text-lg leading-relaxed">{content}</p>
              <div className="text-sm text-muted-foreground">
                Slide {index + 1} of {total}
              </div>
            </motion.div>

            <motion.div 
              className="order-first md:order-last"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.1 }}
            >
              <AspectRatio ratio={16/9}>
                <img
                  src={image}
                  alt={title}
                  className="rounded-lg object-cover w-full h-full shadow-lg hover:scale-[1.02] transition-transform duration-300"
                />
              </AspectRatio>
            </motion.div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}