import { Progress as ProgressBar } from "@/components/ui/progress";
import { motion } from "framer-motion";

interface ProgressProps {
  current: number;
  total: number;
}

export function Progress({ current, total }: ProgressProps) {
  const progress = (current / total) * 100;

  return (
    <motion.div 
      className="absolute bottom-0 left-0 w-full px-4 py-2"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <ProgressBar 
        value={progress} 
        className="h-1.5 bg-primary/20" 
      />
      <div className="absolute right-6 bottom-3 text-xs text-muted-foreground">
        {current} / {total}
      </div>
    </motion.div>
  );
}