import { useState, useEffect } from "react";
import { SlideDeck } from "@/components/slides/slide-deck";
import { SlideContent } from "@/components/slides/slide-content";
import { EditSlide } from "@/components/slides/edit-slide";
import { ThemeSelector } from "@/components/theme-selector";
import { Button } from "@/components/ui/button";
import { Pencil, Save } from "lucide-react";

const defaultSlides = [
  {
    title: "AI Coding",
    subtitle: "By Connor Crossley",
    image: "",
    content: ""
  },
  {
    title: "Table of Contents",
    image: "client\src\pages\images\Screenshot 2025-02-24 132525.png",
    content: ""
  },
  {
    title: "AI Coding",
    image: "client/src/pages/images/Screenshot 2025-02-24 132525.png",
    content: "Ai code = mid, Ai analyization for learning = not mid"
  },
  {
    title: "Recent developments in AI coding",
    image: "https://images.unsplash.com/photo-1499673610122-01c7122c5dcb",
    content: "Some new developments in AI coding include: DeepSeek, Replit, AlphaFold, and the Majorana 1 chip."
  },
  {
    title: "How AI Understands Code",
    image: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7",
    content: "AI does not actually read in the traditional sense. It analyzes your code then based on its training data guesses what may suit your needs."
  },
  {
    title: "Crutching on AI code",
    image: "https://images.unsplash.com/photo-1483817101829-339b08e8d83f",
    content: "AI is a really powerful tool whenever you use it properly. Dont ctrl c ctrl v."
  },
  {
    title: "Replit",
    image: "client\src\pages\images\3c2f2d404a571d2c9fbca934360352698d63433a-1920x900.avif",
    content: "What is Replit? Replits performance."
  },
  {
    title: "ChatGPT",
    image: "client\src\pages\images\openAI-chat-gpt-1-4-1024x623.jpg",
    content: "How can you use Chat GPT the most effectively for learning and for projects (Continue and Copilot)."
  },
  {
    title: "DeepSeek",
    image: "client\src\pages\images\deepresize1.jpg",
    content: "China does it better for cheaper. You may also have Formaldehyde in your seasoned rocks."
  },
  {
    title: "Sources",
    image: "https://images.unsplash.com/photo-1607705703571-c5a8695f18f6",
    content: "chatgpt.com"
  }
];

export default function Presentation() {
  const [slides, setSlides] = useState(defaultSlides);
  const [isEditing, setIsEditing] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  useEffect(() => {
    const savedSlides = localStorage.getItem("presentation-slides");
    if (savedSlides) {
      setSlides(JSON.parse(savedSlides));
    }
  }, []);

  const handleSaveSlide = (data: { title: string; subtitle?: string; content: string; image: string }) => {
    const newSlides = [...slides];
    if (editingIndex !== null) {
      newSlides[editingIndex] = data;
      setSlides(newSlides);
      localStorage.setItem("presentation-slides", JSON.stringify(newSlides));
    }
    setEditingIndex(null);
  };

  const toggleEditMode = () => {
    setIsEditing(!isEditing);
    setEditingIndex(null);
  };

  const resetToDefault = () => {
    setSlides(defaultSlides);
    localStorage.removeItem("presentation-slides");
    setIsEditing(false);
    setEditingIndex(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        <ThemeSelector />
        <Button
          variant="outline"
          size="icon"
          onClick={toggleEditMode}
          className="bg-background"
        >
          {isEditing ? <Save className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
        </Button>
        {isEditing && (
          <Button
            variant="outline"
            onClick={resetToDefault}
            className="bg-background text-sm"
          >
            Reset to Default
          </Button>
        )}
      </div>

      {editingIndex !== null ? (
        <div className="min-h-screen flex items-center justify-center bg-background/80 backdrop-blur">
          <EditSlide
            {...slides[editingIndex]}
            onSave={handleSaveSlide}
            onCancel={() => setEditingIndex(null)}
          />
        </div>
      ) : (
        <SlideDeck>
          {slides.map((slide, index) => (
            <div key={index} className="relative">
              <SlideContent
                {...slide}
                index={index}
                total={slides.length}
              />
              {isEditing && (
                <Button
                  variant="outline"
                  className="absolute top-4 right-4 bg-background"
                  onClick={() => setEditingIndex(index)}
                >
                  Edit Slide
                </Button>
              )}
            </div>
          ))}
        </SlideDeck>
      )}
    </div>
  );
}